import React, { useState } from "react";
import ReactDOM from "react-dom";
import { Model } from "../data/models";

interface ModelModalProps {
  model: Model;
  onClose: () => void;
}

export const ModelModal: React.FC<ModelModalProps> = ({ model, onClose }) => {
  const [galleryIdx, setGalleryIdx] = useState(0);
  const gallery =
    model.gallery && model.gallery.length > 0 ? model.gallery : [model.img];

  // Портал в body
  return ReactDOM.createPortal(
    <div
      className="modal-overlay"
      onClick={onClose}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        background: "rgba(0,0,0,0.7)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 9999,
      }}
    >
      <div
        className="modal-window"
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "#fff",
          borderRadius: "12px",
          maxWidth: "800px",
          width: "90%",
          maxHeight: "90vh",
          overflowY: "auto",
          padding: "20px",
        }}
      >
        <button
          onClick={onClose}
          style={{
            position: "absolute",
            top: "20px",
            right: "20px",
            fontSize: "2rem",
            background: "transparent",
            border: "none",
            cursor: "pointer",
            color: "#fff",
          }}
        >
          ×
        </button>

        <div className="modal-gallery">
          <img
            src={gallery[galleryIdx]}
            alt={model.title}
            style={{
              width: "100%",
              borderRadius: "8px",
              marginBottom: "16px",
            }}
          />
          {gallery.length > 1 && (
            <div
              className="modal-thumbnails"
              style={{
                display: "flex",
                gap: "8px",
                justifyContent: "center",
                flexWrap: "wrap",
              }}
            >
              {gallery.map((img, idx) => (
                <img
                  key={img}
                  src={img}
                  alt={`gallery-${idx}`}
                  style={{
                    width: "80px",
                    height: "60px",
                    objectFit: "cover",
                    borderRadius: "6px",
                    cursor: "pointer",
                    border: galleryIdx === idx ? "2px solid #000" : "none",
                  }}
                  onClick={() => setGalleryIdx(idx)}
                />
              ))}
            </div>
          )}
        </div>

        <h2>{model.title}</h2>
        <span>{model.brand}</span>
        <p>{model.desc}</p>
        {model.year && (
          <div>
            <b>Год выпуска:</b> {model.year}
          </div>
        )}
        {model.price && (
          <div>
            <b>Цена установки:</b> {model.price}
          </div>
        )}
        {model.features && (
          <ul>
            {model.features.map((f, i) => (
              <li key={i}>{f}</li>
            ))}
          </ul>
        )}
        <a href="#contacts" className="btn btn-primary">
          Оставить заявку
        </a>
      </div>
    </div>,
    document.body
  );
};
