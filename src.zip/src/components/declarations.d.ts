declare module 'aos';
declare module "swiper/react";
declare module "swiper/modules";
